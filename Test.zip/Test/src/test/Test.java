/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package test;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *s
 * @author Aluno
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic her
    
        try {
             File file = new File("fileName.txt");
            if(!file.exists()){ 
            file.createNewFile();
        }
        PrintWriter pw = new PrintWriter(file);
        pw.println("Olá");
        pw.close();
            System.out.println("Cabo");
        } catch (IOException e) {
         e.printStackTrace();
        }
        
    
    
    }
    
}
