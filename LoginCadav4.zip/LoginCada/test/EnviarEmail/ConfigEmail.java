package EnviarEmail;

import java.util.Properties;
import java.util.Random;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class ConfigEmail {
    
    private void ConfiguraçãoEmail(String destinatario, String assunto, String mensagem) throws MessagingException {
        // Configurações do servidor de email
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        // Informações de autenticação
        final String remetente = "nnovasraizes@gmail.com"; // Substitua pelo seu endereço de email
        final String senha = "snfpmvuozcsevvxs"; // Substitua pela sua senha de email

        // Cria uma sessão com as configurações e informações de autenticação
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(remetente, senha);
            }
        });

        // Cria uma mensagem de email
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(remetente));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        message.setSubject(assunto);
        message.setText(mensagem);

        // Envia a mensagem
        Transport.send(message);

        JOptionPane.showMessageDialog(null, "Email enviado com sucesso!");
    }
    
    public void enviarEmail(String destinatario, String assunto, String mensagem) {
        try {
            ConfiguraçãoEmail(destinatario, assunto, mensagem);

        } catch (MessagingException e) {
            JOptionPane.showMessageDialog(null, "Erro ao enviar o email: " + e);
        }
    }
    
    public static void main(String[] args) {
       new ConfigEmail().enviarEmail("nnovasraizes@gmail.com", "Assunto", "Teste");
    }
    
    
    
    
    
    
}
