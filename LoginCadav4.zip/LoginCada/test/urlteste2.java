
import java.awt.Desktop;
import java.net.URL;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class urlteste2 {
    String URRL = "https://api.whatsapp.com/send/?phone="; 
    String TELL ="5521991435054";
    String URLL = "&text&type=phone_number&app_absent=0";        
    
    public  void openWebpage(String urlString) {
    try {
        
        Desktop.getDesktop().browse(new URL(URRL +TELL + URLL ).toURI());
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
}
