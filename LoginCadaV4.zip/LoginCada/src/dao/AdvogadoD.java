/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import factory.ConnectionFactory;
import java.awt.Image;
import java.awt.List;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import modelo.Advogado;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import modelo.admin;

/**
 *
 * @author estagiario
 */
public class AdvogadoD {
    Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;

    private Connection connection;
    ArrayList<Advogado> lista = new ArrayList<>();
    Long id;
    String nome;
    String oab;
    String login;
    String senha;
    String email;
    

public AdvogadoD () {
 this.connection = new ConnectionFactory().getConnection();
}
public void buscarimagem(JLabel LBfotousuario, String id) {
        String sql = "select * from advogado where id = ? ";

        try {
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, id);
            ResultSet res = stmt.executeQuery();

        if (res.next()) {
                Blob blob = (Blob) res.getBlob(6);
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;

                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                   
                }
                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(LBfotousuario.getWidth(),
                        LBfotousuario.getHeight(), Image.SCALE_SMOOTH));
                LBfotousuario.setIcon(foto);

            } else {
                JOptionPane.showMessageDialog(null, "Foto não cadastrada!");
            }

        } catch (Exception e) {
            
        }

    }
public ArrayList<Advogado> PesquisarAdvogado(){
        String sql = "select * from advogado";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               Advogado Advogado = new Advogado();
               Advogado.setId(res.getInt("id"));
               Advogado.setLoginAdvogado(res.getString("login"));
               Advogado.setSenhaAdvogado(res.getString("senha"));
               Advogado.setEmailAdvogado(res.getString("email"));
               Advogado.setNomeAdvogado(res.getString("nome"));
               Advogado.setOab(res.getString("oab"));
               lista.add(Advogado);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }  
 public boolean CheckLogin(String login, String senha){
         Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
         
           boolean check = false;
       try{
           stmt = con.prepareStatement("SELECT * FROM advogado WHERE login = ? and senha = ?");
           stmt.setString(1, login);
           stmt.setString(2, senha);
           rs = stmt.executeQuery();
           
           if (rs.next()){
               
               check = true;
               
           }
           
           while (rs.next()){
               Advogado Advogado = new Advogado();
               Advogado.setLoginAdvogado(rs.getString("login"));
               Advogado.setSenhaAdvogado(rs.getString("senha"));
           }
       } catch (SQLException ex){
           Logger.getLogger(AdmintD.class.getName()).log(Level.SEVERE,null, ex);
       } finally {
           ConnectionFactory.closeConnection(con, stmt, rs);
       }
      return check;
     }
  public boolean CheckEmail(String email){
         Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
         
           boolean check = false;
       try{
           stmt = con.prepareStatement("SELECT * FROM advogado WHERE email=?");
           stmt.setString(1, email);
          
           rs = stmt.executeQuery();
           
           if (rs.next()){
               
               check = true;
               
           }
           
           while (rs.next()){
               Advogado Advogado = new Advogado();
               Advogado.setEmailAdvogado(rs.getString("email"));
 
           }
       } catch (SQLException ex){
           Logger.getLogger(AdmintD.class.getName()).log(Level.SEVERE,null, ex);
       } finally {
           ConnectionFactory.closeConnection(con, stmt, rs);
       }
      return check;
        }
  
  public void excluiradvogado(Advogado advogado){
    String sqli = "delete from advogado where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,advogado.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }
  public void excluirProcesso(Advogado advogado){
    String sqli = "delete from processo where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,advogado.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }
}



