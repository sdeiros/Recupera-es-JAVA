import java.util.Date;
import java.text.SimpleDateFormat;

public class PegarDataEmJava {
    public static void main(String[] args) {
        // Obter a data atual
        Date dataAtual = new Date();

        // Criar um formato de data desejado (por exemplo, "dd/MM/yyyy HH:mm:ss")
        SimpleDateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        // Formatar a data como uma string
        String dataFormatada = formatoData.format(dataAtual);

        // Imprimir a data formatada
        System.out.println("Data atual: " + dataFormatada);
    }
}
