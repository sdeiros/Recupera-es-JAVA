import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

public class ObterData {
    public static void main(String[] args) {
        LocalDate dataAtual = LocalDate.now(); // Apenas data
        LocalTime horaAtual = LocalTime.now(); // Apenas hora
        LocalDateTime dataHoraAtual = LocalDateTime.now(); // Data e hora

        System.out.println("Data: " + dataAtual);
        System.out.println("Hora: " + horaAtual);
        System.out.println("Data e Hora: " + dataHoraAtual);
    }
}