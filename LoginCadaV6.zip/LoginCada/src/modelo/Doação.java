/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Aluno
 */
public class Doação {
    int id;
    String tipodedoação;
    String quantidadoação;
    String origemdoação;
    String status;
            
    public String getTipodedoação() {
        return tipodedoação;
    }
    public void setTipodedoação(String tipodedoação) {
        this.tipodedoação = tipodedoação;
    }
    public String getQuantidadedoação() {
        return quantidadoação;
    }
    public void setQuantidadoação(String quantidadoação) {
        this.quantidadoação = quantidadoação;
    }
    public int getId() {
        return id;        
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getOrigemdoação() {
        return origemdoação;
    }
    public void setOrigemdoação(String origemdoação) {
        this.origemdoação = origemdoação;
    }
     public String getStatus() {
        return status;
    }
    public void SetStatus(String status) {
        this.status = status;
    }
}
