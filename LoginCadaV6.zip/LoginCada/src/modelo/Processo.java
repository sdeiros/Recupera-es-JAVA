/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Aluno
 */
public class Processo {

    int id;
    String nome;
    String telefone;
    String email;
    String status;
    String data;

    public String getData(){
        return data;
    }
    
    public void setData (String data) {
        this.data = data;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public int getId() {
        return id;        
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email = email;
    }
     public String getStatus() {
        return status;
    }
    public void SetStatus(String status) {
        this.status = status;
    }
    }
    

