/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.SimpleEmail;

public class JavaMail {
    public void Email(String[] args) {
        
        String Email = "nnovasraizes@gmail.com";
        String Senha = "NovasRaizes@2023";
        
        
        SimpleEmail email = new SimpleEmail();
        
        email.setHostName("smtp.gmail.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator(Email,Senha));
        email.setSSLOnConnect(true);
        
        try{
            email.setFrom(Email);
            email.setSubject("Processo iniciado ");
            email.setMsg("Saudações seu processo foi iniciado por um advogado registrado");
            email.addTo("215002.aluno@iserj.edu.br");
            email.send();
            System.out.println("Deu bom viado");
        } catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
    
    
}
