package modelo;

/**
 *
 * @author Fernando Moreira
 */
public class ong {
    int id;     
    String nome;     
    String endereço;     
    String email;     
    String telefone;
    String caminhoFoto;
    public String getEndereço() {
        return endereço;
    }
    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }
    public String getEmailong() {
        return email;
    }
    public void setEmailong(String email) {
        this.email = email;
    }
    public int getId() {
        return id;        
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNomeong() {
        return nome;
    }
    public void setNomeong(String nome) {
        this.nome = nome;
    }
    public String getTelefoneong() {
        return telefone;
    }
    public void setTelefoneong(String telefone) {
        this.telefone = telefone;
    }
      public String getCaminhoFoto() {
        return caminhoFoto;
    }
    public void SetCaminhoFoto(String caminhoFoto) {
        this.caminhoFoto = caminhoFoto;
    }


}
