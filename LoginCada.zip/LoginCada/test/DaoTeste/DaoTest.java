/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DaoTeste;

import Modelo.Model;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.admin;

/**
 *
 * @author Aluno
 */
public class DaoTest {
     ArrayList<Model> lista = new ArrayList<>();
     private Connection connection;

     public ArrayList<Model> PesquisarTest(){
        String sql = "select * from teste";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               Model Model = new Model();
               Model.setId(res.getInt("id"));
               Model.setNome(res.getString("nome"));
               Model.setTelefone(res.getString("telefone"));
               
               lista.add(Model);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }

}
