/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author estagiario
 */
public class Advogado {
    int id;
    String nome;
    String oab;
    String login;
    String senha;
    String email;
    

 public String getNomeAdvogado() {
        return nome;
    }
    public void setNomeAdvogado(String nome) {
        this.nome = nome;
    }
    public String getOab() {
        return oab;
    }
    public void setOab(String oab) {
        this.oab = oab;
    }
    public String getLoginAdvogado() {
        return login;
    }
    public void setLoginAdvogado(String login) {
        this.login = login;
    }
    public String getSenhaAdvogado() {
        return senha;
    }
    public void setSenhaAdvogado(String senha) {
        this.senha = senha;
    }
    public int getId() {
        return id;        
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getEmailAdvogado() {
        return email;
    }
    public void setEmailAdvogado(String email) {
        this.email = email;
    }
}