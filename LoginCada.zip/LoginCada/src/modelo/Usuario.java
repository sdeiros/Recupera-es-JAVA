package modelo;

/**
 *
 * @author Fernando Moreira
 */
public class Usuario {
    int id;     
    String nome;     
    String naturalidade;     
    String email;     
    String senha;
    String caminhofoto;
    
    public int getId(){
     return id;
    }
    public void setId(int id){
    this.id = id;
    }
    public String getNaturalidade() {
        return naturalidade;
    }
    public void setNaturalidade(String naturalidade) {
        this.naturalidade = naturalidade;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
     public String getCaminhoFoto() {
        return caminhofoto;
    }
    public void SetCaminhoFoto(String caminhoFoto) {
        this.caminhofoto = caminhofoto;
    }

    public void setcnpj(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void setnomefornecedor(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
