package modelo;

/**
 *
 * @author Fernando Moreira
 */
public class admin {
    int id;     
    String login;     
    String senha;     
    String email;     
    String telefone;
    String caminhoFoto;
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getId() {
        return id;        
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
      public String getCaminhoFoto() {
        return caminhoFoto;
    }
    public void SetCaminhoFoto(String caminhoFoto) {
        this.caminhoFoto = caminhoFoto;
    }

   
}
