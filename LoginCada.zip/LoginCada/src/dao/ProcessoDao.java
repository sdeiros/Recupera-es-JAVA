/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Doação;
import modelo.admin;

/**
 *
 * @author Aluno
 */
public class ProcessoDao {

    Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
     ArrayList<Doação> lista = new ArrayList<>();
     private Connection  connection;

    public ArrayList<Doação> PesquisarProcesso(){
        String sql = "select * from teste";
        
        try{
            connection = new ConnectionFactory().getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               Doação Doação = new Doação();
               Doação.setId(res.getInt("id"));
               Doação.setTipodedoação(res.getString("nome"));
               Doação.setOrigemdoação(res.getString("telefone"));
              Doação.setQuantidadoação("email");
              Doação.SetStatus("status");
               
               lista.add(Doação);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }
    
    public void excluir(admin admin){
    String sqli = "delete from teste where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,admin.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }
}
    

